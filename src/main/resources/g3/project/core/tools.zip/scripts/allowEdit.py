def onLoad():
    engine.toggleEdit(True)
def onClose():
    engine.toggleEdit(False)
