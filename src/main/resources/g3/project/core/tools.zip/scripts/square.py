def onLoad():
    print("Loaded Square tool!")

def onClick(button, x, y, isDown):
    print("Clicked with a square")
