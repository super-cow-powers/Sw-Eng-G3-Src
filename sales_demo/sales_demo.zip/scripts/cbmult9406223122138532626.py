def onClick(button, x, y, isDown):
    if isDown:
	handleAlgebra(this.getTextString())

