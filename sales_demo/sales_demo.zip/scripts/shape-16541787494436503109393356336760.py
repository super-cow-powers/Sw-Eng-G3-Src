def onClick(button, x, y, isDown):
    if isDown:
	handleButton(this.getTextString())

