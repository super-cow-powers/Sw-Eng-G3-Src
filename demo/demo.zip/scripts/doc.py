def printa(arg):
      print("printa "+arg)
