def printb(arg):
      print("printb "+arg)

def onClick(button, x, y):
      print(button)
